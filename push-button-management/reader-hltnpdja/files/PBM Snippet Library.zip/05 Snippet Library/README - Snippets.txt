PUSH BUTTON MANAGEMENT: SNIPPET LIBRARY

The same snippets in five formats. Pick the one that matches your tool:

  PBM Snippets - All.txt      Plain text. Paste into Stream Deck Text actions, aText, Alfred, or Outlook Quick Parts.
  PBM Snippets - All.csv      Spreadsheet with group, name, keyword and source for every snippet.
  TextExpander import.csv     TextExpander: File > Import > CSV (abbreviation, content, label). Works on Mac and Windows.
  Espanso pbm.yml             Espanso (free, Windows/Mac/Linux): save into your espanso match folder.
  Raycast snippets.json       Raycast: Import Snippets.

The starter Stream Deck profiles already contain these as buttons in SNIPPETS and SALES > SNIPPETS.

Keywords all start with ;pbm so they never collide with normal typing. The book's advice still applies: a button with a clear label beats a keyword you have to remember (Chapter 7, "Recognition Over Recall"). Use the keywords as a fallback when you are away from your Stream Deck.

"Source" marks which lines come straight from the book and which were written for the toolkit in the same style.
