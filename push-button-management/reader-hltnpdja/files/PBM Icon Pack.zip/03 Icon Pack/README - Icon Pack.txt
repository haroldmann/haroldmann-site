PUSH BUTTON MANAGEMENT: ICON PACK

94 flat, monochrome key icons in the style the book describes (Chapters 1, 6, 9 and Appendix B): one ink color, high contrast, no gradients or shadows. Every icon comes in two versions:

  PNG dark   White on near-black. Matches how most Stream Deck keys look.
  PNG light  Black on white. Matches the Appendix B prompt style.

Pick one version and use it everywhere. Mixing them on one deck defeats the purpose.

SIZE
All PNGs are 288 x 288 pixels. That is the high-resolution key size; the Stream Deck app scales it down cleanly for every model (MK.2, XL, Mini, Neo, +, and the Virtual Stream Deck).

HOW TO PUT AN ICON ON A KEY
1. In the Stream Deck app, select the key.
2. In the settings panel at the bottom, click the small arrow next to the key image.
3. Choose "Set from File" and pick the PNG.
Leave the key's Title field empty. The label is already part of the icon.

WHAT'S IN EACH FOLDER
  01 Folders     The ten top-level folders from Chapter 9, plus BACK.
  02 Inbox       Snooze presets (LATER, AM, PM, 1W, 1M), Delegate, the four +address routes, Discard.
  03 People      #GMS example, a blank "#" key for your own initials, a Meet With placeholder, Weekly sheet, Weekly Dashboard.
  04 Links       Weekly Checklist, Dashboard, Browser.
  05 Snippets    Check-In, Follow-Up, Feedback Request, and seven reply types from Chapter 7.
  06 Sales       All 13 SALES folder keys from Chapter 12, the six sales snippets, and the clean-room browser.
  07 Meetings    1:1, Sales Call, All-Hands, Vendor, Join, Notes, On Air, DND, Record.
  08 AI Tools    Generic AI keys. Use each tool's own logo if you prefer.
  09 Apps        Chat, Notes, Files, Terminal, Browser, Calendar, Mail.
  10 Devices     Lamp, Lights, On Air, Desk, Volume, Camera.
  11 Utilities   DND, Lock, Screenshot, Screen Record, Trash, VPN.
  12 Templates   A blank key.

MAKING YOUR OWN (INITIALS, NEW LABELS)
The "SVG source" folder has the editable original of every icon. Open one in any text editor, change the words between <text ...> and </text>, and save. To turn it into a PNG, open the SVG in a browser, Preview or Figma and export it at 288 x 288. The Toolkit's Button Builder page also makes matching initials and label keys in your browser.

MEET WITH KEYS
The book recommends a photo of each person's face for their Meet With key. The placeholder is there until you have one. Ask each person before using their photo, and use photos your company already makes available for internal use.

The icons use the Inter typeface (SIL Open Font License) for the lettering. The line icons are original drawings made for this toolkit.
