PUSH BUTTON MANAGEMENT: STARTER PROFILES

Four ready-to-import Stream Deck profiles with the ten folders from Chapter 9 already laid out and the book's core buttons already built:

  PBM Starter - Stream Deck MK.2 (Mac)      15-key deck, the book's reference layout
  PBM Starter - Stream Deck MK.2 (Windows)
  PBM Starter - Stream Deck XL (Mac)        32-key deck, same buttons, more room
  PBM Starter - Stream Deck XL (Windows)

Another model (Mini, Neo, +, Virtual)? Import the MK.2 profile, or rebuild from the layout in "Setup - Change These First.pdf". The buttons are the same everywhere.

IMPORT
1. Double-click the .streamDeckProfile file. (Or, in the Stream Deck app: profile dropdown > Edit Profiles > Import.)
2. The profile appears as "PBM Starter". Your existing profiles are not touched.
3. Before pressing anything on real mail, work through "Setup - Change These First.pdf".

WHAT'S BUILT
  INBOX      Snooze: LATER, AM (tomorrow), 1W (next week), PM and 1M (open Gmail's date picker).
             DELEGATE and four +address routes. These open a forward and fill it in; they do NOT send.
  PEOPLE     One full column for Glenn (#GMS): Meet With on top, assign in the middle, Weekly sheet at the bottom.
  LINKS      Weekly sheet in the first slot.
  SALES      All 13 keys from Chapter 12, including the SALES MODE / EXIT switch and a SNIPPETS sub-folder.
  MEETINGS   1:1 Glenn (sheet, #GMS search, notes), JOIN, NOTES.
  SNIPPETS   Check-In, Follow-Up, Feedback, and seven short replies from Chapter 7.
  AI TOOLS   Gemini, ChatGPT, Claude, Perplexity. Put the one you use most in the slot under the folder key.
  APPS, DEVICES, UTILITIES   Empty on purpose: these depend on your own apps and hardware.

SAFETY (from the book)
- Test every Gmail button on a throwaway message first. In Gmail, # is the Delete shortcut: if the label menu has not opened by the time "#GMS" is typed, the message is deleted instead of labeled. Press z right away to undo.
- If a button skips a step, raise its delays by 50 ms.
- The delegation buttons stop before Send on purpose. Check the draft, send it yourself (Cmd+Enter or Ctrl+Enter), then archive the original with e.
- RESEARCH, AI REPLY and LOG IT point at placeholder web addresses. They send clipboard contents to outside services once you connect them; only send data your company allows you to share.
- Gmail's Snooze menu order can change, and late in the day Gmail hides "Later today", which shifts every option up one. After setting up, check that each snooze button brings the message back when you expect.

STATUS
These files were built from the current Stream Deck profile format (app version 7.6) and have not yet been import-tested on every model and operating system. The Windows versions in particular use Windows key codes that have not been verified on a Windows machine. If an import fails or a key misfires, use the layout sheet to rebuild that button by hand.
