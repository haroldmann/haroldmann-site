# PBM Prompt Pack

## Part 1: Icon prompts

Paste the Global Style Prompt first, then add one Subject line, and paste the two together into your image generator (ChatGPT, Gemini, Midjourney, Firefly or similar). Generate at 1024 x 1024, run it a few times, and keep the cleanest result. The 94 ready-made icons in the Icon Pack were drawn in the same style, so you only need these for buttons the pack does not cover.

### Global Style Prompt (use every time)

Create a single flat, strictly monochromatic icon for a small square hardware button (an Elgato Stream Deck key). Use exactly one ink color, solid black, on a plain pure-white background, with no other colors, tints, or shades anywhere. High contrast, bold and uniform stroke weight, clean geometric lines. No gradients, no shadows, no glow, no 3D, no bevels, no texture, no reflections, no borders, and no background scenery. Keep it minimal and focused: one clear central subject, generous empty margins, and no decorative flourishes, extra detail, or ornamentation. The icon must stay instantly legible when shrunk to about 72 pixels square. Square 1:1 composition, centered.

### Assignment (#GMS)

Subject: the text “#GMS” only, in a heavy uppercase sans-serif, solid black, sized to fill most of the square with even margins and without touching the edges. No icon, no underline, no box, no other graphics, just the bold lettering.

### Weekly Dashboard

Subject: a minimal calendar suggested by a plain square divided into a few even cells, with one small check mark in a single corner. Solid black line work of uniform stroke weight. No numbers, no text, and no extra marks.

### Time-Shift (Alarm)

Subject: a simple alarm clock viewed straight on, with two small bells on top and a plain round face, drawn in solid black with uniform strokes, centered. No numbers, no shading, no background, and only a simple pair of hands at most.

### Delegation

Subject: one bold right-pointing arrow that signals handoff, solid black, with a thick uniform stroke, centered and well inside the margins. Just the single arrow, with no second arrow, no box, no text, and nothing else.

### Check-In Snippet

Subject: one bold check mark, solid black, with a thick uniform stroke, centered and balanced with generous margins. Nothing else: no circle, no box, and no text.

### Weekly Checklist (toolkit addition)

Subject: a checklist of three short horizontal lines, each with a small check mark aligned to its left, solid black, uniform stroke. No paper, no notebook, no clipboard, and no text.

### Sales Follow-Up (toolkit addition)

Subject: a plain envelope with a small round clock overlapping its lower right corner, solid black line work of uniform stroke weight. No text and no motion lines.

### Feedback Request Snippet (toolkit addition)

Subject: one minimal speech bubble outline, centered, solid black with a uniform stroke. Empty inside: no text, dots, or lines.

### INBOX folder (toolkit addition)

Subject: a simple open tray seen straight on, solid black line work of uniform stroke weight. No papers inside and no text.

### PEOPLE folder (toolkit addition)

Subject: two simple head-and-shoulders silhouettes side by side, outline only, solid black with a uniform stroke. No faces and no text.

### LINKS folder (toolkit addition)

Subject: two interlocking chain links on a diagonal, solid black outline with a uniform stroke. No text.

### SALES folder (toolkit addition)

Subject: one bold upward-pointing arrow, solid black, thick uniform stroke, centered. Nothing else.

### MEETINGS folder (toolkit addition)

Subject: a minimal calendar outline with a small round clock overlapping its lower right corner, solid black, uniform stroke. No numbers and no text.

### AI TOOLS folder (toolkit addition)

Subject: one four-pointed sparkle, solid black outline with a uniform stroke, centered. No extra stars and no text.

### APPS folder (toolkit addition)

Subject: four equal rounded squares in a two-by-two grid, solid black outline with a uniform stroke. No text.

### DEVICES folder (toolkit addition)

Subject: a simple desk lamp with a trapezoid shade and a straight stem on a flat base, solid black outline with a uniform stroke. No light rays and no text.

### UTILITIES folder (toolkit addition)

Subject: one plain wrench on a diagonal, solid black outline with a uniform stroke. No text.

### 1:1 Meeting (toolkit addition)

Subject: a head-and-shoulders portrait silhouette with a small calendar overlapping its lower right corner, solid black outline with a uniform stroke. No face details and no text.

### SALES MODE (toolkit addition)

Subject: a single line chart rising from lower left to upper right and ending in an arrowhead, solid black, uniform stroke. No axes, no grid, no text.

### Meet With (face)

No prompt needed. Use a photo of the person's face, with their permission.

## Part 2: AI work prompts

Paste these into the AI tool of your choice, or put them on Stream Deck Text buttons in your AI TOOLS or SALES folder. Only paste information your company allows you to share with that tool.

### RESEARCH briefing

*Use:* SALES folder: copy a prospect's company domain or name, then press.

You are preparing me for a first sales conversation. Using only public information, give me a one-page briefing on the company or person below: what they do, size and stage, recent news from the last 12 months, likely priorities for someone in their role, and three specific questions I could ask that show I did my homework. Flag anything you are unsure of instead of guessing. Keep it under 300 words.

Prospect: [paste]

### AI REPLY draft

*Use:* SALES folder: copy the prospect's message, then press.

Draft a reply to the message below in my voice: short, direct, friendly, no buzzwords, no exclamation points. Answer what they asked, propose one clear next step, and keep it under 120 words. Do not invent facts, prices or commitments; use [brackets] where I need to fill something in.

Their message: [paste]

### 1:1 prep

*Use:* MEETINGS folder: paste the open #GMS threads or Weekly sheet notes.

I have a 1:1 with [Name] in a few minutes. From the notes below, list: (1) decisions I need to make, (2) items that look blocked, with the question I should ask about each, and (3) anything that has been open more than two weeks. Keep it to one screen.

Notes: [paste]

### Turn a reply into a snippet

*Use:* SNIPPETS folder: paste a reply you've written three or more times.

Turn the reply below into a reusable snippet: keep my tone, replace every specific name, date and detail with a [placeholder], and keep it under 80 words so it gets me 70% of the way there. Also suggest a 4 to 8 letter button label.

Reply: [paste]

### Should this be a button?

*Use:* Any time: describe a task you repeat.

Here is a task I repeat at work: [describe it]. Apply three tests: does it repeat at least three times a week, is it multi-step, and does it cause friction or hesitation? If all three are true, write the exact Stream Deck Multi Action steps for it (Hotkey, Text, Delay, Website), with a 200 to 300 ms delay after anything that opens a menu or window. If any test fails, say which one and recommend keeping it manual.
